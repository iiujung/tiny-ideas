package com.linkwall.widget;

import android.app.*;
import android.appwidget.AppWidgetManager;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
 List<Store.Page> pages;int columns;int style=0;LinearLayout root;static final int IMPORT=10,EXPORT=11;
 int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(248,249,251));getWindow().setNavigationBarColor(Color.rgb(248,249,251));getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);pages=Store.load(this);columns=Store.columns(this);style=getSharedPreferences(Store.PREF,0).getInt("pin_style",0);if(style<0||style>2)style=0;render();}
 TextView text(String value,int size){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(Color.DKGRAY);t.setPadding(0,dp(6),0,dp(6));return t;}
 Button button(String value,Runnable action){Button b=new Button(this);b.setText(value);b.setAllCaps(false);b.setOnClickListener(v->action.run());return b;}
 void render(){
  ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(20),dp(32),dp(20),dp(24));root.setBackgroundColor(Color.rgb(248,249,251));scroll.addView(root);setContentView(scroll);
  if(Build.VERSION.SDK_INT>=35)scroll.setOnApplyWindowInsetsListener((v,insets)->{android.graphics.Insets bar=insets.getInsets(WindowInsets.Type.systemBars());v.setPadding(bar.left,bar.top,bar.right,bar.bottom);return insets;});
  root.addView(text("連結管理",24));root.addView(text("主畫面上點每個 Emoji，即可直接開啟對應頁面。",14));
  root.addView(text("小工具外觀",18));RadioGroup styles=new RadioGroup(this);styles.setOrientation(RadioGroup.VERTICAL);String[] labels={"完整清單 · 可捲動","資料夾 2×2 · 9 個連結","橫排 2×1 · 3 個連結"};for(int i=0;i<labels.length;i++){RadioButton b=new RadioButton(this);b.setId(100+i);b.setText(labels[i]);styles.addView(b);}styles.check(100+style);styles.setOnCheckedChangeListener((g,id)->{style=id-100;getSharedPreferences(Store.PREF,0).edit().putInt("pin_style",style).apply();});root.addView(styles);
  root.addView(text("資料夾與橫排可以各自選擇連結；加入後點小工具旁的齒輪即可設定。半透明底色會透出桌布，無法複製 Samsung 專有的模糊效果。",12));
  root.addView(button("加入選取樣式的 Widget",()->{AppWidgetManager manager=AppWidgetManager.getInstance(this);Class<?> provider=style==1?FolderWidget.class:style==2?StripWidget.class:ShortcutWidget.class;if(manager.isRequestPinAppWidgetSupported()){manager.requestPinAppWidget(new ComponentName(this,provider),null,null);}else new AlertDialog.Builder(this).setMessage("長按手機主畫面空白處 → 小工具 → 連結管理，選擇完整清單、資料夾或橫排。").setPositiveButton("知道了",null).show();}));
  root.addView(text("完整清單每排格數（資料夾與橫排固定三欄）",14));RadioGroup choices=new RadioGroup(this);choices.setOrientation(RadioGroup.HORIZONTAL);
  for(int n:new int[]{3,4,5}){RadioButton b=new RadioButton(this);b.setId(n);b.setText(String.valueOf(n));choices.addView(b);}choices.check(columns);choices.setOnCheckedChangeListener((g,id)->{columns=id;persist();});root.addView(choices);
  root.addView(text("排列與顯示",18));root.addView(text("勾選顯示；點數字移動位置；點名稱編輯連結。每次修改會立即套用到 Widget。",12));
  for(int i=0;i<pages.size();i++){
   final Store.Page page=pages.get(i);final int index=i;
   LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(0,dp(4),0,dp(4));
   CheckBox visible=new CheckBox(this);visible.setChecked(!page.hidden);visible.setContentDescription("顯示 "+page.name);visible.setOnCheckedChangeListener((b,checked)->{page.hidden=!checked;persist();});row.addView(visible);
   TextView title=text(page.emoji+"  "+page.name,14);title.setContentDescription("編輯 "+page.name);title.setOnClickListener(v->edit(page));row.addView(title,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
   Button position=button(String.valueOf(i+1),()->position(page,index));position.setContentDescription(page.name+" 的位置 "+(i+1));row.addView(position,new LinearLayout.LayoutParams(dp(64),dp(52)));root.addView(row);
  }
  LinearLayout files=new LinearLayout(this);files.addView(button("匯入網站備份",()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,IMPORT);}),new LinearLayout.LayoutParams(0,-2,1));files.addView(button("匯出設定",()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json").putExtra(Intent.EXTRA_TITLE,"notion-widget.json").addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,EXPORT);}),new LinearLayout.LayoutParams(0,-2,1));root.addView(files);
  root.addView(text("網站端：先點「匯出連結備份」，再於這裡匯入。支援原本的順序與隱藏設定；網頁與 Widget 不會自動同步。入口名稱太長時可能會省略。",12));
 }
 void persist(){try{Store.save(this,pages,columns);}catch(Exception e){new AlertDialog.Builder(this).setTitle("設定尚未保存").setMessage(e.getMessage()).setPositiveButton("知道了",null).show();}}
 void position(Store.Page page,int index){EditText number=new EditText(this);number.setInputType(InputType.TYPE_CLASS_NUMBER);number.setText(String.valueOf(index+1));number.selectAll();AlertDialog dialog=new AlertDialog.Builder(this).setTitle("移動 "+page.name).setMessage("輸入 1–"+pages.size()+" 的位置").setView(number).setNegativeButton("取消",null).setPositiveButton("移動",null).create();dialog.setOnShowListener(d->dialog.getButton(-1).setOnClickListener(v->{try{int n=Integer.parseInt(number.getText().toString());if(n<1||n>pages.size())throw new Exception();pages.remove(page);pages.add(n-1,page);persist();dialog.dismiss();render();}catch(Exception e){number.setError("請輸入 1–"+pages.size());}}));dialog.show();}
 void edit(Store.Page page){LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(20),dp(8),dp(20),0);EditText name=new EditText(this);name.setText(page.name);name.setHint("名稱");EditText emoji=new EditText(this);emoji.setText(page.emoji);emoji.setHint("Emoji");EditText url=new EditText(this);url.setText(page.url);url.setHint("HTTPS 網址");url.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);form.addView(name);form.addView(emoji);form.addView(url);
  AlertDialog d=new AlertDialog.Builder(this).setTitle("編輯入口").setView(form).setNegativeButton("取消",null).setNeutralButton("開啟頁面",(a,b)->open(page.url)).setPositiveButton("儲存",null).create();d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{String n=name.getText().toString().trim(),e=emoji.getText().toString(),u=url.getText().toString().trim();if(n.isEmpty()||n.length()>120){name.setError("請輸入 1–120 字名稱");return;}if(e.length()>40){emoji.setError("Emoji 太長");return;}if(!Store.validUrl(u)){url.setError("請輸入 HTTPS HTTPS 網址");return;}page.name=n;page.emoji=e;page.url=u;persist();d.dismiss();render();}));d.show();
 }
 void open(String url){try{startActivity(ShortcutWidget.linkIntent(this,url));}catch(ActivityNotFoundException e){Toast.makeText(this,"請先安裝 Notion 或可開啟連結的瀏覽器",Toast.LENGTH_LONG).show();}}
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();try{
  if(request==IMPORT){String raw;try(InputStream in=getContentResolver().openInputStream(uri)){raw=Store.read(in,512*1024);}List<Store.Page> imported=Store.parse(raw);int importedColumns=columns;Object obj=new JSONTokener(raw).nextValue();if(obj instanceof JSONObject){int n=((JSONObject)obj).optInt("columns",columns);if(n>=3&&n<=5)importedColumns=n;}final int n=importedColumns;
   new AlertDialog.Builder(this).setTitle("匯入 "+imported.size()+" 個入口？").setMessage("會取代此 App 目前的順序、網址與隱藏設定；原網站不受影響。").setNegativeButton("取消",null).setPositiveButton("匯入",(a,b)->{pages=imported;columns=n;persist();render();}).show();
  }else if(request==EXPORT){try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){out.write(Store.export(this).getBytes(StandardCharsets.UTF_8));}Toast.makeText(this,"已匯出設定",Toast.LENGTH_SHORT).show();}
 }catch(Exception e){new AlertDialog.Builder(this).setTitle("檔案處理失敗").setMessage("請使用 連結管理匯出的 JSON 檔案。\n"+e.getMessage()).setPositiveButton("知道了",null).show();}}
}
