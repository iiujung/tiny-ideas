package com.linkwall.widget;

import android.content.Context;
import android.net.Uri;
import org.json.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

final class Store {
 static final String PREF="notion-widget";
 static class Page {
  String id,name,emoji,url; boolean hidden;
  Page(JSONObject o) throws Exception {
   id=o.getString("id");name=o.getString("name");emoji=o.optString("emoji","📄");url=o.getString("url");hidden=o.optBoolean("hidden",false);
   if(id.trim().isEmpty()||name.trim().isEmpty()||name.length()>120||emoji.length()>40||!validUrl(url))throw new Exception("入口名稱或網址不正確");
  }
  JSONObject json() throws Exception {return new JSONObject().put("id",id).put("name",name).put("emoji",emoji).put("url",url).put("hidden",hidden);}
 }
 static boolean validUrl(String s){try{Uri u=Uri.parse(s);String h=u.getHost();return "https".equals(u.getScheme())&&h!=null&&!h.isEmpty()&&u.getUserInfo()==null;}catch(Exception e){return false;}}
 static List<Page> parse(String raw) throws Exception {
  Object decoded=new JSONTokener(raw).nextValue();JSONArray a=decoded instanceof JSONArray?(JSONArray)decoded:((JSONObject)decoded).getJSONArray("pages");
  if(a.length()<1||a.length()>200)throw new Exception("請提供 1–200 個入口");
  List<Page> result=new ArrayList<>();Set<String> ids=new HashSet<>();
  for(int i=0;i<a.length();i++){Page p=new Page(a.getJSONObject(i));if(!ids.add(p.id))throw new Exception("入口 ID 重複");result.add(p);}
  if(result.isEmpty())throw new Exception("沒有可用的入口");return result;
 }
 static String read(java.io.InputStream in,int limit)throws Exception{if(in==null)throw new Exception("無法讀取檔案");java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))!=-1){if(out.size()+n>limit)throw new Exception("檔案太大");out.write(buffer,0,n);}return new String(out.toByteArray(),StandardCharsets.UTF_8);}
 static List<Page> load(Context c){try{String raw=c.getSharedPreferences(PREF,0).getString("pages",null);if(raw!=null)return parse(raw);}catch(Exception ignored){}try(java.io.InputStream in=c.getAssets().open("pages.json")){return parse(read(in,512*1024));}catch(Exception e){return new ArrayList<>();}}
 static int columns(Context c){int n=c.getSharedPreferences(PREF,0).getInt("columns",3);return n>=3&&n<=5?n:3;}
 static String encode(List<Page> pages) throws Exception {JSONArray a=new JSONArray();for(Page p:pages)a.put(p.json());return a.toString(2);}
 static void save(Context c,List<Page> pages,int columns) throws Exception {
  if(!c.getSharedPreferences(PREF,0).edit().putString("pages",encode(pages)).putInt("columns",columns).commit())throw new Exception("無法儲存設定");
  ShortcutWidget.refresh(c);
 }
 static String export(Context c)throws Exception{return new JSONObject().put("version",1).put("columns",columns(c)).put("pages",new JSONArray(encode(load(c)))).toString(2);}
}
