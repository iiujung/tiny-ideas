package com.linkwall.widget;

import android.content.*;
import android.net.Uri;
import android.text.*;
import android.text.style.AbsoluteSizeSpan;
import android.widget.*;
import java.util.*;

public class ShortcutService extends RemoteViewsService {
 @Override public RemoteViewsFactory onGetViewFactory(Intent intent){return new Factory(getApplicationContext(),intent);}
 static class Factory implements RemoteViewsFactory {
  final Context context;final int width,columns;List<Store.Page> pages=new ArrayList<>();
  Factory(Context c,Intent intent){context=c;width=intent.getIntExtra("width",300);columns=intent.getIntExtra("columns",3);}
  public void onCreate(){onDataSetChanged();}
  public void onDataSetChanged(){List<Store.Page> visible=new ArrayList<>();for(Store.Page p:Store.load(context))if(!p.hidden)visible.add(p);pages=visible;}
  public void onDestroy(){pages.clear();}
  public int getCount(){return pages.size();}
  public RemoteViews getViewAt(int position){if(position<0||position>=pages.size())return null;Store.Page p=pages.get(position);
   RemoteViews v=new RemoteViews(context.getPackageName(),R.layout.tile);
   SpannableString text=new SpannableString(p.emoji+"\n"+p.name);
   text.setSpan(new AbsoluteSizeSpan(columns==3?30:columns==4?26:22,true),0,p.emoji.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
   text.setSpan(new AbsoluteSizeSpan(columns==3?12:10,true),p.emoji.length()+1,text.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
   v.setTextViewText(R.id.tile,text);
   int dp=Math.max(40,(width-24-(columns-1)*12)/columns);v.setInt(R.id.tile,"setHeight",Math.round(dp*context.getResources().getDisplayMetrics().density));
   v.setContentDescription(R.id.tile,p.name);v.setOnClickFillInIntent(R.id.tile,new Intent().setData(Uri.parse(p.url)));return v;
  }
  public RemoteViews getLoadingView(){return null;}
  public int getViewTypeCount(){return 1;}
  public long getItemId(int position){return pages.get(position).id.hashCode();}
  public boolean hasStableIds(){return true;}
 }
}
