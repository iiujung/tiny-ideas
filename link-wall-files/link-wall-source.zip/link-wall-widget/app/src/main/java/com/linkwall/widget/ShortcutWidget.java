package com.linkwall.widget;

import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.content.pm.*;
import android.net.Uri;
import android.os.*;
import android.widget.*;
import java.util.*;

public class ShortcutWidget extends AppWidgetProvider {
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)update(c,m,id);}
 @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,Bundle options){update(c,m,id);}
 static Intent linkIntent(Context c,String url){
  Intent probe=new Intent(Intent.ACTION_VIEW,Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
  PackageManager pm=c.getPackageManager();List<ResolveInfo> targets=pm.queryIntentActivities(probe,0);ResolveInfo chosen=pm.resolveActivity(probe,PackageManager.MATCH_DEFAULT_ONLY);
  for(ResolveInfo r:targets)if(r.activityInfo.packageName.equals("notion.id")){chosen=r;break;}
  if(chosen!=null&&chosen.activityInfo.packageName.equals("android")&&!targets.isEmpty())chosen=targets.get(0);
  if(chosen!=null)probe.setComponent(new ComponentName(chosen.activityInfo.packageName,chosen.activityInfo.name));
  return probe;
 }
 static void update(Context c,AppWidgetManager m,int id){
  AppWidgetProviderInfo info=m.getAppWidgetInfo(id);if(FolderRenderer.compact(info)){FolderRenderer.render(c,m,id,info);return;}
  int n=Store.columns(c);int layout=n==3?R.layout.widget3:n==4?R.layout.widget4:R.layout.widget5;
  RemoteViews v=new RemoteViews(c.getPackageName(),layout);
  String dimension=c.getResources().getConfiguration().orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE?AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH:AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH;
  int width=m.getAppWidgetOptions(id).getInt(dimension,300);
  Intent service=new Intent(c,ShortcutService.class).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id).putExtra("width",width).putExtra("columns",n);
  service.setData(Uri.parse("notionwidget://grid/"+id+"/"+width+"/"+n+"/v2"));v.setRemoteAdapter(R.id.grid,service);v.setEmptyView(R.id.grid,R.id.empty);
  Intent settings=new Intent(c,MainActivity.class);
  v.setOnClickPendingIntent(R.id.settings,PendingIntent.getActivity(c,id,settings,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE,launchOptions()));
  Intent base=new Intent(c,OpenPageActivity.class).setAction(Intent.ACTION_VIEW).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
  int flags=PendingIntent.FLAG_UPDATE_CURRENT;if(Build.VERSION.SDK_INT>=31)flags|=PendingIntent.FLAG_MUTABLE;
  v.setPendingIntentTemplate(R.id.grid,PendingIntent.getActivity(c,id+200000,base,flags,launchOptions()));
  m.updateAppWidget(id,v);
 }
 static Bundle launchOptions(){
  if(Build.VERSION.SDK_INT>=35){ActivityOptions options=ActivityOptions.makeBasic();options.setPendingIntentCreatorBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED);return options.toBundle();}
  return null;
 }
 @Override public void onReceive(Context c,Intent intent){super.onReceive(c,intent);if(Intent.ACTION_MY_PACKAGE_REPLACED.equals(intent.getAction()))refresh(c);}
 @Override public void onDeleted(Context c,int[] ids){android.content.SharedPreferences.Editor editor=c.getSharedPreferences(Store.PREF,0).edit();for(int id:ids)editor.remove("widget_ids_"+id).remove("widget_title_"+id);editor.apply();}
 static void refresh(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);for(Class<?> provider:new Class<?>[]{ShortcutWidget.class,FolderWidget.class,StripWidget.class}){int[] ids=m.getAppWidgetIds(new ComponentName(c,provider));for(int id:ids)update(c,m,id);if(provider==ShortcutWidget.class)m.notifyAppWidgetViewDataChanged(ids,R.id.grid);}}
}
