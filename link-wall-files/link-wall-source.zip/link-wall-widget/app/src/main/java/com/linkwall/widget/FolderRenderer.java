package com.linkwall.widget;

import android.app.PendingIntent;
import android.appwidget.*;
import android.content.*;
import android.graphics.*;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;
import org.json.JSONArray;
import java.util.*;

final class FolderRenderer {
 static int capacity(AppWidgetProviderInfo info){return info!=null&&info.provider.getClassName().endsWith("StripWidget")?3:9;}
 static boolean compact(AppWidgetProviderInfo info){return info!=null&&(info.provider.getClassName().endsWith("FolderWidget")||info.provider.getClassName().endsWith("StripWidget"));}
 static List<String> selection(Context c,int id,int capacity){List<String> out=new ArrayList<>();String raw=c.getSharedPreferences(Store.PREF,0).getString("widget_ids_"+id,null);if(raw!=null){try{JSONArray a=new JSONArray(raw);for(int i=0;i<capacity;i++)out.add(a.optString(i,""));return out;}catch(Exception ignored){}}
  for(Store.Page p:Store.load(c))if(!p.hidden&&out.size()<capacity)out.add(p.id);while(out.size()<capacity)out.add("");return out;}
 static void render(Context c,AppWidgetManager manager,int id,AppWidgetProviderInfo info){
  int capacity=capacity(info),rows=capacity==9?3:1;RemoteViews views=new RemoteViews(c.getPackageName(),capacity==9?R.layout.widget_folder:R.layout.widget_strip);
  Bundle options=manager.getAppWidgetOptions(id);boolean landscape=c.getResources().getConfiguration().orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE;
  int width=options.getInt(landscape?AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH:AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,180);
  int height=options.getInt(landscape?AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT:AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT,capacity==9?180:80);
  float density=c.getResources().getDisplayMetrics().density;int side=Math.max(16,Math.min(48,Math.min((width-16)/3-6,(height-40)/rows-6)));int pixels=Math.max(16,Math.min(128,Math.round(side*density)));
  List<Store.Page> all=Store.load(c);List<String> ids=selection(c,id,capacity);
  for(int i=0;i<capacity;i++){
   int slot=c.getResources().getIdentifier("slot"+i,"id",c.getPackageName()),icon=c.getResources().getIdentifier("icon"+i,"id",c.getPackageName());Store.Page page=null;for(Store.Page p:all)if(p.id.equals(ids.get(i))){page=p;break;}
   views.setViewVisibility(slot,page==null?View.INVISIBLE:View.VISIBLE);if(page==null)continue;
   views.setImageViewBitmap(icon,icon(page.emoji,pixels));views.setContentDescription(slot,page.name);
   Intent click=new Intent(c,OpenPageActivity.class).setAction(Intent.ACTION_VIEW).setData(android.net.Uri.parse(page.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
   views.setOnClickPendingIntent(slot,PendingIntent.getActivity(c,id*16+i,click,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE,ShortcutWidget.launchOptions()));
  }
  String title=c.getSharedPreferences(Store.PREF,0).getString("widget_title_"+id,"Notion");views.setTextViewText(R.id.folder_title,title);
  Intent setup=new Intent(c,WidgetSetupActivity.class).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);
  views.setOnClickPendingIntent(R.id.settings,PendingIntent.getActivity(c,id+300000,setup,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE,ShortcutWidget.launchOptions()));manager.updateAppWidget(id,views);
 }
 static Bitmap icon(String emoji,int size){Bitmap b=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(b);Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setColor(Color.WHITE);canvas.drawRoundRect(0,0,size,size,size*.27f,size*.27f,paint);paint.setColor(Color.BLACK);paint.setTextSize(size*.61f);paint.setTextAlign(Paint.Align.CENTER);Paint.FontMetrics fm=paint.getFontMetrics();canvas.drawText(emoji,size/2f,size/2f-(fm.ascent+fm.descent)/2f,paint);return b;}
}
