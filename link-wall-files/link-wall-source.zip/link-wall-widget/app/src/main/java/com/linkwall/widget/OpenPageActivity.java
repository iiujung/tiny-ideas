package com.linkwall.widget;

import android.app.Activity;
import android.content.*;
import android.os.Bundle;
import android.widget.Toast;

/** Receives a widget tap directly as an Activity, then resolves its actual page URL. */
public class OpenPageActivity extends Activity {
 @Override public void onCreate(Bundle state){super.onCreate(state);open(getIntent());}
 private void open(Intent request){
  String url=request.getDataString();
  if(!Store.validUrl(url)){Toast.makeText(this,"此入口的網址無效，請到設定重新儲存。",Toast.LENGTH_LONG).show();finish();return;}
  try{startActivity(ShortcutWidget.linkIntent(this,url));}
  catch(ActivityNotFoundException|SecurityException e){
   try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE));}
   catch(ActivityNotFoundException|SecurityException fallback){Toast.makeText(this,"無法開啟連結，請先安裝 Notion 或瀏覽器。",Toast.LENGTH_LONG).show();}
  }
  finish();
 }
}
