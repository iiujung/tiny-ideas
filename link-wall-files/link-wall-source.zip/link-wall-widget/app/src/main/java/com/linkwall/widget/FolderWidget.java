package com.linkwall.widget;
public class FolderWidget extends ShortcutWidget {}
