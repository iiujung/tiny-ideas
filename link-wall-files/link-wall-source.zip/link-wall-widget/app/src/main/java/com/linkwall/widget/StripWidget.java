package com.linkwall.widget;
public class StripWidget extends ShortcutWidget {}
