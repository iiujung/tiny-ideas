# 連結管理 Widget 分享版

Android 8.0 以上；以公開網站為示範，不含私人 Notion 頁面。

先於連結管理網頁建立入口、匯出 JSON，再於 App 匯入網站備份。支援 HTTPS 網址。網頁與 App 不會自動同步；匯入會取代 App 原有的連結清單，請先匯出備份。

完整清單可選 3／4／5 欄；資料夾 2×2 放 9 個入口；橫排 2×1 放 3 個入口。資料夾與橫排在加入後點齒輪選擇連結。手機桌面實際占格依 Launcher 而異。

Java 17、Gradle 8.11.1、Android SDK 35。執行 ./gradlew assembleDebug lintDebug。此分享包為測試簽章版，非 Google Play 上架版。套件 com.linkwall.widget，與原個人版分開安裝。

App 不要求網路權限，連結交給外部 App／瀏覽器開啟。瀏覽器或 Notion 原有登入與頁面權限仍適用。
